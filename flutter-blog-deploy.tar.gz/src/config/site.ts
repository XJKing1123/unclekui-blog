export const SITE = {
  title: 'Flutter Field Notes',
  shortTitle: '奎叔笔记',
  description: '面向 Flutter 工程师的深度技术专栏，记录框架原理、性能、架构、安全与稳定性实践。',
  author: {
    name: '奎叔',
    role: 'Flutter / Mobile Engineer',
    bio: '十年移动端研发经验，持续记录可验证、可落地的 Flutter 工程实践。',
    email: 'JKingx1123@gmail.com',
    avatar: '/author-placeholder.png',
  },
  nav: [
    { label: '首页', href: '/' },
    { label: '文章', href: '/posts' },
    { label: '专栏', href: '/series' },
    { label: '标签', href: '/tags' },
  ],
} as const;

export const SERIES = {
  dart: {
    name: 'Dart 语言与运行时',
    description: '深入 Dart 类型系统、异步模型、编译管线、运行时与内存管理。',
  },
  'state-management': {
    name: '状态与数据流',
    description: '围绕状态建模、数据流向、并发一致性与界面响应构建可预测的 Flutter 应用。',
  },
  networking: {
    name: '网络与请求治理',
    description: '治理请求生命周期、认证刷新、重试、幂等性与弱网环境下的数据一致性。',
  },
  'framework-internals': {
    name: '框架原理',
    description: '从三棵树、渲染管线到混合开发，理解 Flutter 的运行机制。',
  },
  'performance-reliability': {
    name: '性能与稳定性',
    description: '用指标、Trace 和故障闭环建设可观测、可恢复的客户端。',
  },
  security: {
    name: '客户端安全',
    description: '从威胁模型出发，建立输入、凭证、存储和运行环境的纵深防御。',
  },
  engineering: {
    name: '工程架构',
    description: '围绕模块边界、依赖管理和本地化建设可持续演进的工程体系。',
  },
} as const;

export type SeriesKey = keyof typeof SERIES;
